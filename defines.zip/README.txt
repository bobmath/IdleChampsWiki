These definitions are downloaded to the client as needed, so this collection is incomplete.

Keys starting with an underscore are added by me for various reasons, and not present in the original data.
